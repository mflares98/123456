<script>
    $(document).ready( function () {
        $("#print").on("click",function(){
            window.print();
        });
    });
</script>